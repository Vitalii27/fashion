jQuery(function ($) {
    var $accrodions = $(".accordion");
    var $accrodion = $accrodions.find(".item");
    var closeClass = "is-close";
    var speed = 200;
    var isClose = false;


    function openAccordion() {
        closeAll();
        $(this).removeClass(closeClass);
        $(this).find(".accordion_content").slideDown(speed);
    }

    function closeAccordion() {
        $(this).addClass(closeClass);
        $(this).find(".accordion_content").slideUp(speed);
    }

    function closeAll() {
        $accrodion.each(function (i, el) {
            closeAccordion.call(el);
        });
    }

    if ($accrodion.length) {
        $accrodion.each(function (i, el) {
            console.log($(el));
            var btn = $(el).find(".accordion_title");

            if (!isClose) {
                closeAccordion.call(el);
            }

            btn.on("click", function () {
                console.log("click");
                if ($(el).hasClass(closeClass)) {
                    openAccordion.call(el);
                } else {
                    closeAccordion.call(el);
                }
            });
        });// end .each()
    }
    $('.button-block .button').on('click', function (e) {
        e.preventDefault();
        var height = $('.text-content-more .content-vissible').height();
        $('.text-content-more .content').css('height', height)
    })

    $('.sidebar-vissible').on('click', function (e) {
        e.preventDefault();
        if (!$('.products-sidebar').hasClass('sidebar-open')) {
            $('.products-sidebar').addClass('sidebar-open')
        } else {
            $('.products-sidebar').removeClass('sidebar-open')
        }
    })

});
// alert.js

function Alert(selector) {

	this.selector = selector;

	this.alertClass = "is-shown";

	this.alertTimeout = null;

	this.init();

}
Alert.prototype =
		{
			//constructor: Alert,
			init: function () {
				var _this = this;

				//close btn
				$(_this.selector).find(".js-alert-close").on("click", function (e) {
					e.stopPropagation();
					_this.hideAlert.apply(_this);
				});

				// hover
				$(_this.selector).hover(function () {
							_this.mouseIn.apply(_this);
						},
						function () {
							_this.mouseOut.apply(_this);
						});
			},
			showAlert: function (text) {
				var _this = this;
				$(_this.selector).addClass(_this.alertClass);
				$(_this.selector).find(".alert_text").html(text);

				_this.alertTimeout = setTimeout(function () {
					_this.hideAlert.apply(_this);
				}, 3000);
			},

			hideAlert: function () {
				var _this = this;
				$(_this.selector).removeClass(_this.alertClass);
				if (_this.alertTimeout) {
					clearTimeout(_this.alertTimeout);
					_this.alertTimeout = null;
				}

			},

			mouseIn: function () {
				clearTimeout(this.alertTimeout);
				this.alertTimeout = null;
			},

			mouseOut: function () {
				var _this = this;
				_this.alertTimeout = setTimeout(function () {
					_this.hideAlert.apply(_this);
				}, 3000);
			}
		};

var alert;
$(function () {
	alert = new Alert(".js-alert");
	if ($(alert.selector).length) {
		alert.showAlert('<i class="fa fa-info-circle" aria-hidden="true"></i> Lorem ipsum dolor sit amet, consectetur adipisicing elit.  <a href="#0">В корзину</a>');
	}
/*	$("body").on("click", function () {
		alert.showAlert('<i class="fa fa-info-circle" aria-hidden="true"></i> You make a click');
	});*/
});//ready


// alert.js end
//Animate CSS + WayPoints javaScript Plugin + device.js
//Example: $(".element").animated("zoomInUp", "zoomOutDown");
(function ($) {
  $.fn.animated = function (inEffect, outEffect) {
    $(this).css("opacity", "0").addClass("animated").waypoint(function (dir) {
      if (dir === "down") {
        $(this).removeClass(outEffect).addClass(inEffect).css("opacity", "1");
      } else {
        $(this).removeClass(inEffect).addClass(outEffect).css("opacity", "1");
      }
    }, {
      offset: $(window).height()
    }).waypoint(function (dir) {
      if (dir === "down") {
        $(this).removeClass(inEffect).addClass(outEffect).css("opacity", "1");
      } else {
        $(this).removeClass(outEffect).addClass(inEffect).css("opacity", "1");
      }
    }, {
      offset: -$(window).height()
    });
  };
})(jQuery);

(function ($) {
  $.fn.animated_once = function (inEffect) {
    $(this).css("opacity", "0").addClass("animated").waypoint(function (dir) {

      $(this).addClass(inEffect).css("opacity", "1");

    }, {
      offset: $(window).height()
    });
  };
})(jQuery);

(function ($) {
  $.fn.waypointTriger = function (cb) {
    $(this).waypoint(function (dir) {
      if (dir === "down") {
        cb($(this));
      }
    }, {
      offset: $(window).height()
    }).waypoint(function (dir) {
      if (dir === "up") {
        cb($(this));
      }
    }, {
      offset: -$(window).height()
    });
  };
})(jQuery);

(function ($) {

  $(window).on('load', function () {
    $("body").css("opacity", 1);
  });


  var media = window.matchMedia("only screen and (max-width: 62em)").matches;

  if (!device.mobile() && !media) {
    //$("#services").animated("fadeInUp", "fadeOutDown");
    $(".js-animation-in").animated_once("fadeIn");
    $(".js-animation-inLeft").animated_once("fadeInLeft");
    $(".js-animation-inRight").animated_once("fadeInRight");
    $(".js-animation-tinUp").animated_once("tinUp");
    //$(".js-animation-in").animated_once("fadeIn");
    //$(".js-animation-left").animated_once("fadeInLeft");
    //$("#contact").animated_once("svg");




    //$("#services").waypointf(unction ($this) {
    //  $('.services-item').each(function (i) {
    //
    //    setTimeout(function () {
    //
    //      var svg = new Vivus('clip-full-' + i, {
    //        type: 'oneByOne',
    //        duration: 100
    //      }, function (obj) {
    //        obj.el.classList.add('animate-fill');
    //      });
    //
    //    }, 500 * i);
    //
    //  });
    //}, {
    //  offset: $(window).height()
    //});
  }

})(jQuery);
var detectModule = (function ($) {
	// prived block

	function isMobile() {
		if (device.mobile() || $('html').hasClass("tablet") || $('html').hasClass("detect-mobile")) {
			return true;
		}
	}
	function isMicrosoft() {
		if (navigator.userAgent.match(/MSIE 10/i) || navigator.userAgent.match(/Trident\/7\./) || navigator.userAgent.match(/Edge\/12\./)) {
			$('html').addClass("detect-microsoft");
			return true;
		}
	}
	function isIE() {
		if (navigator.userAgent.match(/MSIE/i) || navigator.userAgent.match(/Trident\/7\./)) {
			$('html').addClass("detect-ie");
			return true;
		}
	}
	function isEdge() {
		if (navigator.userAgent.match(/Edge\//)) {
			$('html').addClass("detect-edge");
			return true;
		}
	}

	function getScrollBarWidth() {
		var $outer = $('<div>').css({
					visibility: 'hidden',
					width: 100,
					overflow: 'scroll'
				}).appendTo('body'),
				widthWithScroll = $('<div>').css({
					width: '100%'
				}).appendTo($outer).outerWidth();
		$outer.remove();
		return 100 - widthWithScroll;
	}

	return {
		// public methods
		scrollBarWidth: getScrollBarWidth(),
		isMobile: isMobile(),
		isMicrosoft: isMicrosoft(),
		isIE: isIE(),
		isEdge: isEdge()
	}
}(jQuery));
// google map api
//AIzaSyDHHUnlsnx3cOKdUiz3cmH8z0V2VLOD-oA
//
jQuery(function ($) {
  var markersInstance = {};
  // create infowindow
  var infoWindow = null;

  function initMap(mapConfig) {

    // Specify features and elements to define styles.

    var isDraggable = jQuery(document).width() > 768 ? true : false; // If document (your website) is wider than 768px, isDraggable = true, else isDraggable = false

    var styledMapType = new google.maps.StyledMapType([
          {
            "featureType": "administrative",
            "elementType": "all",
            "stylers": [
              {
                "visibility": "simplified"
              }
            ]
          },
          {
            "featureType": "administrative.locality",
            "elementType": "labels",
            "stylers": [
              {
                "color": "#ba5858"
              }
            ]
          },
          {
            "featureType": "administrative.neighborhood",
            "elementType": "labels",
            "stylers": [
              {
                "color": "#e57878"
              }
            ]
          },
          {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [
              {
                "visibility": "simplified"
              },
              {
                "color": "#fcfcfc"
              }
            ]
          },
          {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [
              {
                "visibility": "simplified"
              },
              {
                "color": "#fcfcfc"
              }
            ]
          },
          {
            "featureType": "poi",
            "elementType": "labels",
            "stylers": [
              {
                "visibility": "off"
              }
            ]
          },
          {
            "featureType": "poi.attraction",
            "elementType": "labels",
            "stylers": [
              {
                "visibility": "off"
              }
            ]
          },
          {
            "featureType": "road.highway",
            "elementType": "geometry",
            "stylers": [
              {
                "visibility": "simplified"
              },
              {
                "color": "#dddddd"
              }
            ]
          },
          {
            "featureType": "road.highway",
            "elementType": "labels",
            "stylers": [
              {
                "visibility": "off"
              }
            ]
          },
          {
            "featureType": "road.highway.controlled_access",
            "elementType": "labels",
            "stylers": [
              {
                "visibility": "off"
              }
            ]
          },
          {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [
              {
                "visibility": "simplified"
              },
              {
                "color": "#dddddd"
              }
            ]
          },
          {
            "featureType": "road.arterial",
            "elementType": "labels",
            "stylers": [
              {
                "visibility": "off"
              }
            ]
          },
          {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [
              {
                "visibility": "simplified"
              },
              {
                "color": "#eeeeee"
              }
            ]
          },
          {
            "featureType": "road.local",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#ba5858"
              }
            ]
          },
          {
            "featureType": "transit.station",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#ba5858"
              }
            ]
          },
          {
            "featureType": "transit.station",
            "elementType": "labels.icon",
            "stylers": [
              {
                "hue": "#ff0036"
              }
            ]
          },
          {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [
              {
                "visibility": "simplified"
              },
              {
                "color": "#dddddd"
              }
            ]
          },
          {
            "featureType": "water",
            "elementType": "labels.text.fill",
            "stylers": [
              {
                "color": "#ba5858"
              }
            ]
          }
        ],
        {name: 'Styled Map'});

    var mapOptions = {
      draggable: isDraggable,
      center: {
        lat: mapConfig.mapCenter[0],
        lng: mapConfig.mapCenter[1]
      },
      // Apply the map style array to the map.
      zoom: mapConfig.zoom,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      panControl: false,
      zoomControl: true,
      mapTypeControl: false,
      scaleControl: false,
      streetViewControl: true,
      overviewMapControl: false,
      scrollwheel: false,// Prevent users to start zooming the map when scrolling down the page
      mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain',
          'styled_map']
      }
      //... options options options
    };
    // Create a map object and specify the DOM element for display.
    gMap = new google.maps.Map(document.getElementById('g-map'), mapOptions);
    gMap.mapTypes.set('styled_map', styledMapType);
    gMap.setMapTypeId('styled_map');

    // create markers
    var markers = mapConfig.markers;
    var markerPosition = {};

    for (var marker in markers) {

      // // create new marker position instance
      markerPosition[marker] = new google.maps.LatLng(markers[marker].center[0], markers[marker].center[1]);
      // create new marker instance
      markersInstance[marker] = new google.maps.Marker({
        position: markerPosition[marker],
        map: gMap,
        title: markers[marker].title
      });
    }


  }// initMap

  function centeringMarker(latitude, longitude) {
    //centering map
    // because gladiolus
    //gMap.setCenter({lat: latitude, lng: longitude});
    gMap.panTo({lat: latitude, lng: longitude});
    //return false;
  }

  $(window).on("load", function () {
    if (typeof mapConfig != "undefined") {
      var gMap;
      initMap(mapConfig);
    }
  });

}); // ready
// google map api end

jQuery(function($){}); // ready

var PopUpModule = (function ($) {
	// private methods
	var _removalDelay = 150;
	var _scrollBarWidth = detectModule.scrollBarWidth;

	var isOpenPopup = function () {
		// console.log("open pop-up");
		$('body').css({
      'padding-right': _scrollBarWidth + "px"
    });
		$("html").addClass("pop-up-is-showed");
	};

	var isClosePopup = function () {
		// console.log("close pop-up");
		$("html").removeClass("pop-up-is-showed");
		$('body').css('padding-right', 0);
	};


	return {
		// public methods
		initInline: function (selector) {
			$(selector).data("ignore-scroll", true);
			$(selector).magnificPopup({
				type: 'inline',
				preloader: false,
				removalDelay: _removalDelay,
				mainClass: 'mfp-fade',
				overflowY: 'visible',
				showCloseBtn: true,
				callbacks: {
					open: isOpenPopup,
					close: isClosePopup
				}
			});
		},

		initAjax: function (selector) {
			$(selector).data("ignore-scroll", true);
			var _this = this;
			$(selector).magnificPopup({
				type: 'ajax',
				preloader: true,
				removalDelay: _removalDelay,
				mainClass: 'mfp-fade',
				overflowY: 'hidden',
				showCloseBtn: false,
				callbacks: {
					open: isOpenPopup,
					ajaxContentAdded: function () {
						// FormStyler.initSelect(".select");
						// console.log(_this);
						// _this.initAjax(".js-pop-up-ajax");
					},
					close: isClosePopup
				}
			});
		},

		open: function (html) {
			$.magnificPopup.close();
			//wait for animation
			setTimeout(function () {
				// Open directly via API
				$.magnificPopup.open({
					items: {
						src: html, // can be a HTML string, jQuery object, or CSS selector
						type: 'inline'
					},
					removalDelay: _removalDelay,
					mainClass: 'mfp-fade',
					overflowY: 'scroll',
					showCloseBtn: false,
					callbacks: {
						open: function () {
							isOpenPopup();
							// FormStyler.initSelect(".select");
							// ProductSlider.init(".js-product-slider", ".js-product-thumbs");
						},
						close: isClosePopup
					}
				});
			}, _removalDelay);
		},
		openAjax: function (href, setting) {
			var _this = this;
			$.ajax({
				url: href,
				type: 'GET',
				success: function (data) {
					//console.log(data);
					_this.open(data);
				}
			});

		}
	}
}(jQuery));

jQuery(function ($) {
	PopUpModule.initInline(".js-pop-up");
	//PopUpModule.initAjax(".js-pop-up-ajax");
}); // ready

(function ($) {

  var filters = $('.portfolio  [data-filter]');
  var grid = $('.portfolio-grid');
  var activeClass = 'is-show';
  var media = window.matchMedia("(max-width: 48em)");

  grid.isotope({
    percentPosition: true,
    layoutMode: 'fitRows',
    itemSelector: '.portfolio-grid_item',
    masonry: {
      columnWidth: '.portfolio-grid_item'
    }
  });

  filters.click(function () {
    filters.removeClass('is-active');
    $(this).addClass('is-active');

    var selector = $(this).attr('data-filter');
    grid.isotope({
      filter: selector
    });
    return false;
  });

  if (media.matches) {
    $(".portfolio_filters").removeClass(activeClass);
    $(".dropdown").addClass(activeClass);
  } else {
    $(".portfolio_filters").addClass(activeClass);
    $(".dropdown").removeClass(activeClass);
  }

  $(window).resize(function () {
    media = window.matchMedia("only screen and (max-width: 48em)");

    if (media.matches) {
      $(".portfolio_filters").removeClass(activeClass);
      $(".dropdown").addClass(activeClass);
    } else {
      $(".portfolio_filters").addClass(activeClass);
      $(".dropdown").removeClass(activeClass);
    }

  });


}(jQuery));

// sliders.js
jQuery(function ($) {
    var arrowLeft = '<div class="arrow-slide arrow-left-slide"></div>';
    var arrowRight = '<div class="arrow-slide arrow-right-slide"></div>';
    // preset options
    var heroSlider = $('.banner-slider');
    var heroOption = {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
        fade: true,
        dots: false,
        autoplay: false,
        nextArrow: '<div class="slider_btn--next slider_btn"> ' + arrowRight + ' </div>',
        prevArrow: '<div class="slider_btn--prev slider_btn">' + arrowLeft + '</div>',
        speed: 500,
        infinite: true,

        cssEase: 'linear',
        accessibility: false,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    autoplay: true,
                    // arrows:false
                }


            }
        ]
    };

    // init slider
    heroSlider.slick(heroOption);

    $('.slider-main').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        asNavFor: '.slider-nav',
        vertical: true,
        responsive: [
            {
                breakpoint: 1201,
                settings: {
                    vertical: false
                }


            }
        ]

    });

    $('.slider-nav').slick({
        slidesToShow: 4,
        asNavFor: '.slider-main',
        arrows: true,
        vertical: true,
        focusOnSelect: true,
        nextArrow: '<div class="slider_btn--next slider_btn"> ' + arrowRight + ' </div>',
        prevArrow: '<div class="slider_btn--prev slider_btn">' + arrowLeft + '</div>',
        responsive: [
            {
                breakpoint: 1201,
                settings: {
                    vertical: false,
                    slidesToShow: 3,
                }


            }
        ]
    });
    $('.product-slider').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        arrows: true,
        nextArrow: '<div class="slider_btn--next slider_btn"> ' + arrowRight + ' </div>',
        prevArrow: '<div class="slider_btn--prev slider_btn">' + arrowLeft + '</div>',
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 5,
                }


            }, {
                breakpoint: 769,
                settings: {
                    slidesToShow: 4,
                }


            },{
                breakpoint: 561,
                settings: {
                    slidesToShow: 3,
                }


            },{
                breakpoint: 481,
                settings: {
                    slidesToShow: 2,
                }


            },
        ]
    });
    //
    // $(window).on('resize orientationchange', function() {
    //     if ($(window).width() > 1200) {
    //         $('.slider-nav').slick('unslick');
    //         $('.slider-nav').slick({
    //             slidesToShow: 4,
    //             asNavFor: '.slider-main',
    //             vertical: true,
    //             focusOnSelect: true,
    //             arrows: true,
    //             autoplay: false,
    //         });
    //     }
    // });

}); // ready
// sliders.js end
/* smooth scrolling */
jQuery(function ($) {
	$('a[href*="#"]:not([href="#"])').click(function () {
		if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
			// prevent conflict with tabs and other script used hash
			if ( $(this).data("ignore-scroll") ) return;

			var target = $(this.hash);
			target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
			if (target.length) {
				$('html, body').animate({
					scrollTop: target.offset().top - 50
				}, 1100);
				return false;
			}
		}
	});
});
/* smooth scrolling end*/
jQuery(function ($) {
	// on canvas menu
	var $touch = $('.js-toggle-menu');
	var activeClass = "is-swipe-menu-shown";
	var $menu = $('.swipe-menu');
	var $close = $('.js-menu-close');
	var $wrapper = $("body");
	var startBreakpoint = "1024px";

	// show/hide menu functions
	function showMenu() {
		$wrapper.addClass(activeClass);
		// ios scroll fix
		$("html, body").css({
			height: "100%",
			"overflow-y": "hidden"
		});

	}
	function hideMenu() {
		$wrapper.removeClass(activeClass);
		// ios scroll fix
		$("html, body").css({
			height: "auto",
			"overflow-y": "auto"
		});
	}
	
	// event listeners
	$touch.on('click', function (e) {
		e.preventDefault();
		e.stopPropagation();
		if ( $wrapper.hasClass(activeClass) ) {
			hideMenu();
		} else {
			showMenu();
		}
	});

	$close.on('click', function (e) {
		e.stopPropagation();
		hideMenu();
	});

	$wrapper.on('click', function (e) {
		if (e.target.className !== "swipe-menu") {
			hideMenu();
		}
	});

	$menu.on('click', function (e) {
		e.stopPropagation();
	});

	// close menu if target is an anchor link
	$menu.find('a[href*="#"]:not([href="#"])').on('click', function (e) {
		setTimeout(hideMenu, 1000);
	});

	$(window).resize(function () {
		var media = window.matchMedia("only screen and (max-width: " + startBreakpoint + ")").matches;
		if (!media) {
			hideMenu();
		}
	});
	// on canvas menu end
});
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjY29yZGlvbi5qcyIsImFsZXJ0LmpzIiwiYW5pbWF0aW9uLmpzIiwiZGV0ZWN0LmpzIiwiZ29vZ2xlLW1hcC5qcyIsIm1haW4uanMiLCJwb3AtdXAuanMiLCJwb3J0Zm9saW9GaWx0ZXJzLmpzIiwic2xpZGVycy5qcyIsInNtb290aC1zY3JvbGwuanMiLCJzd2lwZS1tZW51LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQzNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQzlFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2hHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2hEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ3JRQTtBQUNBO0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDeEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2xEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2pJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2xCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJtYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsialF1ZXJ5KGZ1bmN0aW9uICgkKSB7XHJcbiAgICB2YXIgJGFjY3JvZGlvbnMgPSAkKFwiLmFjY29yZGlvblwiKTtcclxuICAgIHZhciAkYWNjcm9kaW9uID0gJGFjY3JvZGlvbnMuZmluZChcIi5pdGVtXCIpO1xyXG4gICAgdmFyIGNsb3NlQ2xhc3MgPSBcImlzLWNsb3NlXCI7XHJcbiAgICB2YXIgc3BlZWQgPSAyMDA7XHJcbiAgICB2YXIgaXNDbG9zZSA9IGZhbHNlO1xyXG5cclxuXHJcbiAgICBmdW5jdGlvbiBvcGVuQWNjb3JkaW9uKCkge1xyXG4gICAgICAgIGNsb3NlQWxsKCk7XHJcbiAgICAgICAgJCh0aGlzKS5yZW1vdmVDbGFzcyhjbG9zZUNsYXNzKTtcclxuICAgICAgICAkKHRoaXMpLmZpbmQoXCIuYWNjb3JkaW9uX2NvbnRlbnRcIikuc2xpZGVEb3duKHNwZWVkKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBjbG9zZUFjY29yZGlvbigpIHtcclxuICAgICAgICAkKHRoaXMpLmFkZENsYXNzKGNsb3NlQ2xhc3MpO1xyXG4gICAgICAgICQodGhpcykuZmluZChcIi5hY2NvcmRpb25fY29udGVudFwiKS5zbGlkZVVwKHNwZWVkKTtcclxuICAgIH1cclxuXHJcbiAgICBmdW5jdGlvbiBjbG9zZUFsbCgpIHtcclxuICAgICAgICAkYWNjcm9kaW9uLmVhY2goZnVuY3Rpb24gKGksIGVsKSB7XHJcbiAgICAgICAgICAgIGNsb3NlQWNjb3JkaW9uLmNhbGwoZWwpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICgkYWNjcm9kaW9uLmxlbmd0aCkge1xyXG4gICAgICAgICRhY2Nyb2Rpb24uZWFjaChmdW5jdGlvbiAoaSwgZWwpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJChlbCkpO1xyXG4gICAgICAgICAgICB2YXIgYnRuID0gJChlbCkuZmluZChcIi5hY2NvcmRpb25fdGl0bGVcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIWlzQ2xvc2UpIHtcclxuICAgICAgICAgICAgICAgIGNsb3NlQWNjb3JkaW9uLmNhbGwoZWwpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBidG4ub24oXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNsaWNrXCIpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCQoZWwpLmhhc0NsYXNzKGNsb3NlQ2xhc3MpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb3BlbkFjY29yZGlvbi5jYWxsKGVsKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2xvc2VBY2NvcmRpb24uY2FsbChlbCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pOy8vIGVuZCAuZWFjaCgpXHJcbiAgICB9XHJcbiAgICAkKCcuYnV0dG9uLWJsb2NrIC5idXR0b24nKS5vbignY2xpY2snLCBmdW5jdGlvbiAoZSkge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICB2YXIgaGVpZ2h0ID0gJCgnLnRleHQtY29udGVudC1tb3JlIC5jb250ZW50LXZpc3NpYmxlJykuaGVpZ2h0KCk7XHJcbiAgICAgICAgJCgnLnRleHQtY29udGVudC1tb3JlIC5jb250ZW50JykuY3NzKCdoZWlnaHQnLCBoZWlnaHQpXHJcbiAgICB9KVxyXG5cclxuICAgICQoJy5zaWRlYmFyLXZpc3NpYmxlJykub24oJ2NsaWNrJywgZnVuY3Rpb24gKGUpIHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgaWYgKCEkKCcucHJvZHVjdHMtc2lkZWJhcicpLmhhc0NsYXNzKCdzaWRlYmFyLW9wZW4nKSkge1xyXG4gICAgICAgICAgICAkKCcucHJvZHVjdHMtc2lkZWJhcicpLmFkZENsYXNzKCdzaWRlYmFyLW9wZW4nKVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICQoJy5wcm9kdWN0cy1zaWRlYmFyJykucmVtb3ZlQ2xhc3MoJ3NpZGViYXItb3BlbicpXHJcbiAgICAgICAgfVxyXG4gICAgfSlcclxuXHJcbn0pOyIsIi8vIGFsZXJ0LmpzXHJcblxyXG5mdW5jdGlvbiBBbGVydChzZWxlY3Rvcikge1xyXG5cclxuXHR0aGlzLnNlbGVjdG9yID0gc2VsZWN0b3I7XHJcblxyXG5cdHRoaXMuYWxlcnRDbGFzcyA9IFwiaXMtc2hvd25cIjtcclxuXHJcblx0dGhpcy5hbGVydFRpbWVvdXQgPSBudWxsO1xyXG5cclxuXHR0aGlzLmluaXQoKTtcclxuXHJcbn1cclxuQWxlcnQucHJvdG90eXBlID1cclxuXHRcdHtcclxuXHRcdFx0Ly9jb25zdHJ1Y3RvcjogQWxlcnQsXHJcblx0XHRcdGluaXQ6IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHR2YXIgX3RoaXMgPSB0aGlzO1xyXG5cclxuXHRcdFx0XHQvL2Nsb3NlIGJ0blxyXG5cdFx0XHRcdCQoX3RoaXMuc2VsZWN0b3IpLmZpbmQoXCIuanMtYWxlcnQtY2xvc2VcIikub24oXCJjbGlja1wiLCBmdW5jdGlvbiAoZSkge1xyXG5cdFx0XHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHRcdFx0XHRcdF90aGlzLmhpZGVBbGVydC5hcHBseShfdGhpcyk7XHJcblx0XHRcdFx0fSk7XHJcblxyXG5cdFx0XHRcdC8vIGhvdmVyXHJcblx0XHRcdFx0JChfdGhpcy5zZWxlY3RvcikuaG92ZXIoZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdFx0XHRcdF90aGlzLm1vdXNlSW4uYXBwbHkoX3RoaXMpO1xyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRcdFx0X3RoaXMubW91c2VPdXQuYXBwbHkoX3RoaXMpO1xyXG5cdFx0XHRcdFx0XHR9KTtcclxuXHRcdFx0fSxcclxuXHRcdFx0c2hvd0FsZXJ0OiBmdW5jdGlvbiAodGV4dCkge1xyXG5cdFx0XHRcdHZhciBfdGhpcyA9IHRoaXM7XHJcblx0XHRcdFx0JChfdGhpcy5zZWxlY3RvcikuYWRkQ2xhc3MoX3RoaXMuYWxlcnRDbGFzcyk7XHJcblx0XHRcdFx0JChfdGhpcy5zZWxlY3RvcikuZmluZChcIi5hbGVydF90ZXh0XCIpLmh0bWwodGV4dCk7XHJcblxyXG5cdFx0XHRcdF90aGlzLmFsZXJ0VGltZW91dCA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdFx0X3RoaXMuaGlkZUFsZXJ0LmFwcGx5KF90aGlzKTtcclxuXHRcdFx0XHR9LCAzMDAwKTtcclxuXHRcdFx0fSxcclxuXHJcblx0XHRcdGhpZGVBbGVydDogZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdHZhciBfdGhpcyA9IHRoaXM7XHJcblx0XHRcdFx0JChfdGhpcy5zZWxlY3RvcikucmVtb3ZlQ2xhc3MoX3RoaXMuYWxlcnRDbGFzcyk7XHJcblx0XHRcdFx0aWYgKF90aGlzLmFsZXJ0VGltZW91dCkge1xyXG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KF90aGlzLmFsZXJ0VGltZW91dCk7XHJcblx0XHRcdFx0XHRfdGhpcy5hbGVydFRpbWVvdXQgPSBudWxsO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdH0sXHJcblxyXG5cdFx0XHRtb3VzZUluOiBmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRoaXMuYWxlcnRUaW1lb3V0KTtcclxuXHRcdFx0XHR0aGlzLmFsZXJ0VGltZW91dCA9IG51bGw7XHJcblx0XHRcdH0sXHJcblxyXG5cdFx0XHRtb3VzZU91dDogZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdHZhciBfdGhpcyA9IHRoaXM7XHJcblx0XHRcdFx0X3RoaXMuYWxlcnRUaW1lb3V0ID0gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcblx0XHRcdFx0XHRfdGhpcy5oaWRlQWxlcnQuYXBwbHkoX3RoaXMpO1xyXG5cdFx0XHRcdH0sIDMwMDApO1xyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cclxudmFyIGFsZXJ0O1xyXG4kKGZ1bmN0aW9uICgpIHtcclxuXHRhbGVydCA9IG5ldyBBbGVydChcIi5qcy1hbGVydFwiKTtcclxuXHRpZiAoJChhbGVydC5zZWxlY3RvcikubGVuZ3RoKSB7XHJcblx0XHRhbGVydC5zaG93QWxlcnQoJzxpIGNsYXNzPVwiZmEgZmEtaW5mby1jaXJjbGVcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+IExvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBjb25zZWN0ZXR1ciBhZGlwaXNpY2luZyBlbGl0LiAgPGEgaHJlZj1cIiMwXCI+0JIg0LrQvtGA0LfQuNC90YM8L2E+Jyk7XHJcblx0fVxyXG4vKlx0JChcImJvZHlcIikub24oXCJjbGlja1wiLCBmdW5jdGlvbiAoKSB7XHJcblx0XHRhbGVydC5zaG93QWxlcnQoJzxpIGNsYXNzPVwiZmEgZmEtaW5mby1jaXJjbGVcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48L2k+IFlvdSBtYWtlIGEgY2xpY2snKTtcclxuXHR9KTsqL1xyXG59KTsvL3JlYWR5XHJcblxyXG5cclxuLy8gYWxlcnQuanMgZW5kIiwiLy9BbmltYXRlIENTUyArIFdheVBvaW50cyBqYXZhU2NyaXB0IFBsdWdpbiArIGRldmljZS5qc1xyXG4vL0V4YW1wbGU6ICQoXCIuZWxlbWVudFwiKS5hbmltYXRlZChcInpvb21JblVwXCIsIFwiem9vbU91dERvd25cIik7XHJcbihmdW5jdGlvbiAoJCkge1xyXG4gICQuZm4uYW5pbWF0ZWQgPSBmdW5jdGlvbiAoaW5FZmZlY3QsIG91dEVmZmVjdCkge1xyXG4gICAgJCh0aGlzKS5jc3MoXCJvcGFjaXR5XCIsIFwiMFwiKS5hZGRDbGFzcyhcImFuaW1hdGVkXCIpLndheXBvaW50KGZ1bmN0aW9uIChkaXIpIHtcclxuICAgICAgaWYgKGRpciA9PT0gXCJkb3duXCIpIHtcclxuICAgICAgICAkKHRoaXMpLnJlbW92ZUNsYXNzKG91dEVmZmVjdCkuYWRkQ2xhc3MoaW5FZmZlY3QpLmNzcyhcIm9wYWNpdHlcIiwgXCIxXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgICQodGhpcykucmVtb3ZlQ2xhc3MoaW5FZmZlY3QpLmFkZENsYXNzKG91dEVmZmVjdCkuY3NzKFwib3BhY2l0eVwiLCBcIjFcIik7XHJcbiAgICAgIH1cclxuICAgIH0sIHtcclxuICAgICAgb2Zmc2V0OiAkKHdpbmRvdykuaGVpZ2h0KClcclxuICAgIH0pLndheXBvaW50KGZ1bmN0aW9uIChkaXIpIHtcclxuICAgICAgaWYgKGRpciA9PT0gXCJkb3duXCIpIHtcclxuICAgICAgICAkKHRoaXMpLnJlbW92ZUNsYXNzKGluRWZmZWN0KS5hZGRDbGFzcyhvdXRFZmZlY3QpLmNzcyhcIm9wYWNpdHlcIiwgXCIxXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgICQodGhpcykucmVtb3ZlQ2xhc3Mob3V0RWZmZWN0KS5hZGRDbGFzcyhpbkVmZmVjdCkuY3NzKFwib3BhY2l0eVwiLCBcIjFcIik7XHJcbiAgICAgIH1cclxuICAgIH0sIHtcclxuICAgICAgb2Zmc2V0OiAtJCh3aW5kb3cpLmhlaWdodCgpXHJcbiAgICB9KTtcclxuICB9O1xyXG59KShqUXVlcnkpO1xyXG5cclxuKGZ1bmN0aW9uICgkKSB7XHJcbiAgJC5mbi5hbmltYXRlZF9vbmNlID0gZnVuY3Rpb24gKGluRWZmZWN0KSB7XHJcbiAgICAkKHRoaXMpLmNzcyhcIm9wYWNpdHlcIiwgXCIwXCIpLmFkZENsYXNzKFwiYW5pbWF0ZWRcIikud2F5cG9pbnQoZnVuY3Rpb24gKGRpcikge1xyXG5cclxuICAgICAgJCh0aGlzKS5hZGRDbGFzcyhpbkVmZmVjdCkuY3NzKFwib3BhY2l0eVwiLCBcIjFcIik7XHJcblxyXG4gICAgfSwge1xyXG4gICAgICBvZmZzZXQ6ICQod2luZG93KS5oZWlnaHQoKVxyXG4gICAgfSk7XHJcbiAgfTtcclxufSkoalF1ZXJ5KTtcclxuXHJcbihmdW5jdGlvbiAoJCkge1xyXG4gICQuZm4ud2F5cG9pbnRUcmlnZXIgPSBmdW5jdGlvbiAoY2IpIHtcclxuICAgICQodGhpcykud2F5cG9pbnQoZnVuY3Rpb24gKGRpcikge1xyXG4gICAgICBpZiAoZGlyID09PSBcImRvd25cIikge1xyXG4gICAgICAgIGNiKCQodGhpcykpO1xyXG4gICAgICB9XHJcbiAgICB9LCB7XHJcbiAgICAgIG9mZnNldDogJCh3aW5kb3cpLmhlaWdodCgpXHJcbiAgICB9KS53YXlwb2ludChmdW5jdGlvbiAoZGlyKSB7XHJcbiAgICAgIGlmIChkaXIgPT09IFwidXBcIikge1xyXG4gICAgICAgIGNiKCQodGhpcykpO1xyXG4gICAgICB9XHJcbiAgICB9LCB7XHJcbiAgICAgIG9mZnNldDogLSQod2luZG93KS5oZWlnaHQoKVxyXG4gICAgfSk7XHJcbiAgfTtcclxufSkoalF1ZXJ5KTtcclxuXHJcbihmdW5jdGlvbiAoJCkge1xyXG5cclxuICAkKHdpbmRvdykub24oJ2xvYWQnLCBmdW5jdGlvbiAoKSB7XHJcbiAgICAkKFwiYm9keVwiKS5jc3MoXCJvcGFjaXR5XCIsIDEpO1xyXG4gIH0pO1xyXG5cclxuXHJcbiAgdmFyIG1lZGlhID0gd2luZG93Lm1hdGNoTWVkaWEoXCJvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjJlbSlcIikubWF0Y2hlcztcclxuXHJcbiAgaWYgKCFkZXZpY2UubW9iaWxlKCkgJiYgIW1lZGlhKSB7XHJcbiAgICAvLyQoXCIjc2VydmljZXNcIikuYW5pbWF0ZWQoXCJmYWRlSW5VcFwiLCBcImZhZGVPdXREb3duXCIpO1xyXG4gICAgJChcIi5qcy1hbmltYXRpb24taW5cIikuYW5pbWF0ZWRfb25jZShcImZhZGVJblwiKTtcclxuICAgICQoXCIuanMtYW5pbWF0aW9uLWluTGVmdFwiKS5hbmltYXRlZF9vbmNlKFwiZmFkZUluTGVmdFwiKTtcclxuICAgICQoXCIuanMtYW5pbWF0aW9uLWluUmlnaHRcIikuYW5pbWF0ZWRfb25jZShcImZhZGVJblJpZ2h0XCIpO1xyXG4gICAgJChcIi5qcy1hbmltYXRpb24tdGluVXBcIikuYW5pbWF0ZWRfb25jZShcInRpblVwXCIpO1xyXG4gICAgLy8kKFwiLmpzLWFuaW1hdGlvbi1pblwiKS5hbmltYXRlZF9vbmNlKFwiZmFkZUluXCIpO1xyXG4gICAgLy8kKFwiLmpzLWFuaW1hdGlvbi1sZWZ0XCIpLmFuaW1hdGVkX29uY2UoXCJmYWRlSW5MZWZ0XCIpO1xyXG4gICAgLy8kKFwiI2NvbnRhY3RcIikuYW5pbWF0ZWRfb25jZShcInN2Z1wiKTtcclxuXHJcblxyXG5cclxuXHJcbiAgICAvLyQoXCIjc2VydmljZXNcIikud2F5cG9pbnRmKHVuY3Rpb24gKCR0aGlzKSB7XHJcbiAgICAvLyAgJCgnLnNlcnZpY2VzLWl0ZW0nKS5lYWNoKGZ1bmN0aW9uIChpKSB7XHJcbiAgICAvL1xyXG4gICAgLy8gICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XHJcbiAgICAvL1xyXG4gICAgLy8gICAgICB2YXIgc3ZnID0gbmV3IFZpdnVzKCdjbGlwLWZ1bGwtJyArIGksIHtcclxuICAgIC8vICAgICAgICB0eXBlOiAnb25lQnlPbmUnLFxyXG4gICAgLy8gICAgICAgIGR1cmF0aW9uOiAxMDBcclxuICAgIC8vICAgICAgfSwgZnVuY3Rpb24gKG9iaikge1xyXG4gICAgLy8gICAgICAgIG9iai5lbC5jbGFzc0xpc3QuYWRkKCdhbmltYXRlLWZpbGwnKTtcclxuICAgIC8vICAgICAgfSk7XHJcbiAgICAvL1xyXG4gICAgLy8gICAgfSwgNTAwICogaSk7XHJcbiAgICAvL1xyXG4gICAgLy8gIH0pO1xyXG4gICAgLy99LCB7XHJcbiAgICAvLyAgb2Zmc2V0OiAkKHdpbmRvdykuaGVpZ2h0KClcclxuICAgIC8vfSk7XHJcbiAgfVxyXG5cclxufSkoalF1ZXJ5KTsiLCJ2YXIgZGV0ZWN0TW9kdWxlID0gKGZ1bmN0aW9uICgkKSB7XHJcblx0Ly8gcHJpdmVkIGJsb2NrXHJcblxyXG5cdGZ1bmN0aW9uIGlzTW9iaWxlKCkge1xyXG5cdFx0aWYgKGRldmljZS5tb2JpbGUoKSB8fCAkKCdodG1sJykuaGFzQ2xhc3MoXCJ0YWJsZXRcIikgfHwgJCgnaHRtbCcpLmhhc0NsYXNzKFwiZGV0ZWN0LW1vYmlsZVwiKSkge1xyXG5cdFx0XHRyZXR1cm4gdHJ1ZTtcclxuXHRcdH1cclxuXHR9XHJcblx0ZnVuY3Rpb24gaXNNaWNyb3NvZnQoKSB7XHJcblx0XHRpZiAobmF2aWdhdG9yLnVzZXJBZ2VudC5tYXRjaCgvTVNJRSAxMC9pKSB8fCBuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9UcmlkZW50XFwvN1xcLi8pIHx8IG5hdmlnYXRvci51c2VyQWdlbnQubWF0Y2goL0VkZ2VcXC8xMlxcLi8pKSB7XHJcblx0XHRcdCQoJ2h0bWwnKS5hZGRDbGFzcyhcImRldGVjdC1taWNyb3NvZnRcIik7XHJcblx0XHRcdHJldHVybiB0cnVlO1xyXG5cdFx0fVxyXG5cdH1cclxuXHRmdW5jdGlvbiBpc0lFKCkge1xyXG5cdFx0aWYgKG5hdmlnYXRvci51c2VyQWdlbnQubWF0Y2goL01TSUUvaSkgfHwgbmF2aWdhdG9yLnVzZXJBZ2VudC5tYXRjaCgvVHJpZGVudFxcLzdcXC4vKSkge1xyXG5cdFx0XHQkKCdodG1sJykuYWRkQ2xhc3MoXCJkZXRlY3QtaWVcIik7XHJcblx0XHRcdHJldHVybiB0cnVlO1xyXG5cdFx0fVxyXG5cdH1cclxuXHRmdW5jdGlvbiBpc0VkZ2UoKSB7XHJcblx0XHRpZiAobmF2aWdhdG9yLnVzZXJBZ2VudC5tYXRjaCgvRWRnZVxcLy8pKSB7XHJcblx0XHRcdCQoJ2h0bWwnKS5hZGRDbGFzcyhcImRldGVjdC1lZGdlXCIpO1xyXG5cdFx0XHRyZXR1cm4gdHJ1ZTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGdldFNjcm9sbEJhcldpZHRoKCkge1xyXG5cdFx0dmFyICRvdXRlciA9ICQoJzxkaXY+JykuY3NzKHtcclxuXHRcdFx0XHRcdHZpc2liaWxpdHk6ICdoaWRkZW4nLFxyXG5cdFx0XHRcdFx0d2lkdGg6IDEwMCxcclxuXHRcdFx0XHRcdG92ZXJmbG93OiAnc2Nyb2xsJ1xyXG5cdFx0XHRcdH0pLmFwcGVuZFRvKCdib2R5JyksXHJcblx0XHRcdFx0d2lkdGhXaXRoU2Nyb2xsID0gJCgnPGRpdj4nKS5jc3Moe1xyXG5cdFx0XHRcdFx0d2lkdGg6ICcxMDAlJ1xyXG5cdFx0XHRcdH0pLmFwcGVuZFRvKCRvdXRlcikub3V0ZXJXaWR0aCgpO1xyXG5cdFx0JG91dGVyLnJlbW92ZSgpO1xyXG5cdFx0cmV0dXJuIDEwMCAtIHdpZHRoV2l0aFNjcm9sbDtcclxuXHR9XHJcblxyXG5cdHJldHVybiB7XHJcblx0XHQvLyBwdWJsaWMgbWV0aG9kc1xyXG5cdFx0c2Nyb2xsQmFyV2lkdGg6IGdldFNjcm9sbEJhcldpZHRoKCksXHJcblx0XHRpc01vYmlsZTogaXNNb2JpbGUoKSxcclxuXHRcdGlzTWljcm9zb2Z0OiBpc01pY3Jvc29mdCgpLFxyXG5cdFx0aXNJRTogaXNJRSgpLFxyXG5cdFx0aXNFZGdlOiBpc0VkZ2UoKVxyXG5cdH1cclxufShqUXVlcnkpKTsiLCIvLyBnb29nbGUgbWFwIGFwaVxyXG4vL0FJemFTeURISFVubHNueDNjT0tkVWl6M2NtSDh6MFYyVkxPRC1vQVxyXG4vL1xyXG5qUXVlcnkoZnVuY3Rpb24gKCQpIHtcclxuICB2YXIgbWFya2Vyc0luc3RhbmNlID0ge307XHJcbiAgLy8gY3JlYXRlIGluZm93aW5kb3dcclxuICB2YXIgaW5mb1dpbmRvdyA9IG51bGw7XHJcblxyXG4gIGZ1bmN0aW9uIGluaXRNYXAobWFwQ29uZmlnKSB7XHJcblxyXG4gICAgLy8gU3BlY2lmeSBmZWF0dXJlcyBhbmQgZWxlbWVudHMgdG8gZGVmaW5lIHN0eWxlcy5cclxuXHJcbiAgICB2YXIgaXNEcmFnZ2FibGUgPSBqUXVlcnkoZG9jdW1lbnQpLndpZHRoKCkgPiA3NjggPyB0cnVlIDogZmFsc2U7IC8vIElmIGRvY3VtZW50ICh5b3VyIHdlYnNpdGUpIGlzIHdpZGVyIHRoYW4gNzY4cHgsIGlzRHJhZ2dhYmxlID0gdHJ1ZSwgZWxzZSBpc0RyYWdnYWJsZSA9IGZhbHNlXHJcblxyXG4gICAgdmFyIHN0eWxlZE1hcFR5cGUgPSBuZXcgZ29vZ2xlLm1hcHMuU3R5bGVkTWFwVHlwZShbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJhZG1pbmlzdHJhdGl2ZVwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiYWxsXCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwic2ltcGxpZmllZFwiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwiYWRtaW5pc3RyYXRpdmUubG9jYWxpdHlcIixcclxuICAgICAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImxhYmVsc1wiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjYmE1ODU4XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJhZG1pbmlzdHJhdGl2ZS5uZWlnaGJvcmhvb2RcIixcclxuICAgICAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImxhYmVsc1wiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjZTU3ODc4XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJsYW5kc2NhcGVcIixcclxuICAgICAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImdlb21ldHJ5XCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwic2ltcGxpZmllZFwiXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiI2ZjZmNmY1wiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwicG9pXCIsXHJcbiAgICAgICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeVwiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwidmlzaWJpbGl0eVwiOiBcInNpbXBsaWZpZWRcIlxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJjb2xvclwiOiBcIiNmY2ZjZmNcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInBvaVwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwibGFiZWxzXCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwib2ZmXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJwb2kuYXR0cmFjdGlvblwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwibGFiZWxzXCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwib2ZmXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJyb2FkLmhpZ2h3YXlcIixcclxuICAgICAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImdlb21ldHJ5XCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwic2ltcGxpZmllZFwiXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcImNvbG9yXCI6IFwiI2RkZGRkZFwiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwicm9hZC5oaWdod2F5XCIsXHJcbiAgICAgICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJsYWJlbHNcIixcclxuICAgICAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcInZpc2liaWxpdHlcIjogXCJvZmZcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInJvYWQuaGlnaHdheS5jb250cm9sbGVkX2FjY2Vzc1wiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwibGFiZWxzXCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJ2aXNpYmlsaXR5XCI6IFwib2ZmXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJyb2FkLmFydGVyaWFsXCIsXHJcbiAgICAgICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJnZW9tZXRyeVwiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwidmlzaWJpbGl0eVwiOiBcInNpbXBsaWZpZWRcIlxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJjb2xvclwiOiBcIiNkZGRkZGRcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInJvYWQuYXJ0ZXJpYWxcIixcclxuICAgICAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImxhYmVsc1wiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwidmlzaWJpbGl0eVwiOiBcIm9mZlwiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImZlYXR1cmVUeXBlXCI6IFwicm9hZC5sb2NhbFwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiZ2VvbWV0cnlcIixcclxuICAgICAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcInZpc2liaWxpdHlcIjogXCJzaW1wbGlmaWVkXCJcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjZWVlZWVlXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJyb2FkLmxvY2FsXCIsXHJcbiAgICAgICAgICAgIFwiZWxlbWVudFR5cGVcIjogXCJsYWJlbHMudGV4dC5maWxsXCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJjb2xvclwiOiBcIiNiYTU4NThcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJmZWF0dXJlVHlwZVwiOiBcInRyYW5zaXQuc3RhdGlvblwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwibGFiZWxzLnRleHQuZmlsbFwiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjYmE1ODU4XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJ0cmFuc2l0LnN0YXRpb25cIixcclxuICAgICAgICAgICAgXCJlbGVtZW50VHlwZVwiOiBcImxhYmVscy5pY29uXCIsXHJcbiAgICAgICAgICAgIFwic3R5bGVyc1wiOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgXCJodWVcIjogXCIjZmYwMDM2XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJ3YXRlclwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwiZ2VvbWV0cnlcIixcclxuICAgICAgICAgICAgXCJzdHlsZXJzXCI6IFtcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBcInZpc2liaWxpdHlcIjogXCJzaW1wbGlmaWVkXCJcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjZGRkZGRkXCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiZmVhdHVyZVR5cGVcIjogXCJ3YXRlclwiLFxyXG4gICAgICAgICAgICBcImVsZW1lbnRUeXBlXCI6IFwibGFiZWxzLnRleHQuZmlsbFwiLFxyXG4gICAgICAgICAgICBcInN0eWxlcnNcIjogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIFwiY29sb3JcIjogXCIjYmE1ODU4XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH1cclxuICAgICAgICBdLFxyXG4gICAgICAgIHtuYW1lOiAnU3R5bGVkIE1hcCd9KTtcclxuXHJcbiAgICB2YXIgbWFwT3B0aW9ucyA9IHtcclxuICAgICAgZHJhZ2dhYmxlOiBpc0RyYWdnYWJsZSxcclxuICAgICAgY2VudGVyOiB7XHJcbiAgICAgICAgbGF0OiBtYXBDb25maWcubWFwQ2VudGVyWzBdLFxyXG4gICAgICAgIGxuZzogbWFwQ29uZmlnLm1hcENlbnRlclsxXVxyXG4gICAgICB9LFxyXG4gICAgICAvLyBBcHBseSB0aGUgbWFwIHN0eWxlIGFycmF5IHRvIHRoZSBtYXAuXHJcbiAgICAgIHpvb206IG1hcENvbmZpZy56b29tLFxyXG4gICAgICBtYXBUeXBlSWQ6IGdvb2dsZS5tYXBzLk1hcFR5cGVJZC5ST0FETUFQLFxyXG4gICAgICBwYW5Db250cm9sOiBmYWxzZSxcclxuICAgICAgem9vbUNvbnRyb2w6IHRydWUsXHJcbiAgICAgIG1hcFR5cGVDb250cm9sOiBmYWxzZSxcclxuICAgICAgc2NhbGVDb250cm9sOiBmYWxzZSxcclxuICAgICAgc3RyZWV0Vmlld0NvbnRyb2w6IHRydWUsXHJcbiAgICAgIG92ZXJ2aWV3TWFwQ29udHJvbDogZmFsc2UsXHJcbiAgICAgIHNjcm9sbHdoZWVsOiBmYWxzZSwvLyBQcmV2ZW50IHVzZXJzIHRvIHN0YXJ0IHpvb21pbmcgdGhlIG1hcCB3aGVuIHNjcm9sbGluZyBkb3duIHRoZSBwYWdlXHJcbiAgICAgIG1hcFR5cGVDb250cm9sT3B0aW9uczoge1xyXG4gICAgICAgIG1hcFR5cGVJZHM6IFsncm9hZG1hcCcsICdzYXRlbGxpdGUnLCAnaHlicmlkJywgJ3RlcnJhaW4nLFxyXG4gICAgICAgICAgJ3N0eWxlZF9tYXAnXVxyXG4gICAgICB9XHJcbiAgICAgIC8vLi4uIG9wdGlvbnMgb3B0aW9ucyBvcHRpb25zXHJcbiAgICB9O1xyXG4gICAgLy8gQ3JlYXRlIGEgbWFwIG9iamVjdCBhbmQgc3BlY2lmeSB0aGUgRE9NIGVsZW1lbnQgZm9yIGRpc3BsYXkuXHJcbiAgICBnTWFwID0gbmV3IGdvb2dsZS5tYXBzLk1hcChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZy1tYXAnKSwgbWFwT3B0aW9ucyk7XHJcbiAgICBnTWFwLm1hcFR5cGVzLnNldCgnc3R5bGVkX21hcCcsIHN0eWxlZE1hcFR5cGUpO1xyXG4gICAgZ01hcC5zZXRNYXBUeXBlSWQoJ3N0eWxlZF9tYXAnKTtcclxuXHJcbiAgICAvLyBjcmVhdGUgbWFya2Vyc1xyXG4gICAgdmFyIG1hcmtlcnMgPSBtYXBDb25maWcubWFya2VycztcclxuICAgIHZhciBtYXJrZXJQb3NpdGlvbiA9IHt9O1xyXG5cclxuICAgIGZvciAodmFyIG1hcmtlciBpbiBtYXJrZXJzKSB7XHJcblxyXG4gICAgICAvLyAvLyBjcmVhdGUgbmV3IG1hcmtlciBwb3NpdGlvbiBpbnN0YW5jZVxyXG4gICAgICBtYXJrZXJQb3NpdGlvblttYXJrZXJdID0gbmV3IGdvb2dsZS5tYXBzLkxhdExuZyhtYXJrZXJzW21hcmtlcl0uY2VudGVyWzBdLCBtYXJrZXJzW21hcmtlcl0uY2VudGVyWzFdKTtcclxuICAgICAgLy8gY3JlYXRlIG5ldyBtYXJrZXIgaW5zdGFuY2VcclxuICAgICAgbWFya2Vyc0luc3RhbmNlW21hcmtlcl0gPSBuZXcgZ29vZ2xlLm1hcHMuTWFya2VyKHtcclxuICAgICAgICBwb3NpdGlvbjogbWFya2VyUG9zaXRpb25bbWFya2VyXSxcclxuICAgICAgICBtYXA6IGdNYXAsXHJcbiAgICAgICAgdGl0bGU6IG1hcmtlcnNbbWFya2VyXS50aXRsZVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcblxyXG4gIH0vLyBpbml0TWFwXHJcblxyXG4gIGZ1bmN0aW9uIGNlbnRlcmluZ01hcmtlcihsYXRpdHVkZSwgbG9uZ2l0dWRlKSB7XHJcbiAgICAvL2NlbnRlcmluZyBtYXBcclxuICAgIC8vIGJlY2F1c2UgZ2xhZGlvbHVzXHJcbiAgICAvL2dNYXAuc2V0Q2VudGVyKHtsYXQ6IGxhdGl0dWRlLCBsbmc6IGxvbmdpdHVkZX0pO1xyXG4gICAgZ01hcC5wYW5Ubyh7bGF0OiBsYXRpdHVkZSwgbG5nOiBsb25naXR1ZGV9KTtcclxuICAgIC8vcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgJCh3aW5kb3cpLm9uKFwibG9hZFwiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICBpZiAodHlwZW9mIG1hcENvbmZpZyAhPSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgIHZhciBnTWFwO1xyXG4gICAgICBpbml0TWFwKG1hcENvbmZpZyk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG59KTsgLy8gcmVhZHlcclxuLy8gZ29vZ2xlIG1hcCBhcGkgZW5kXHJcbiIsImpRdWVyeShmdW5jdGlvbigkKXt9KTsgLy8gcmVhZHlcclxuIiwidmFyIFBvcFVwTW9kdWxlID0gKGZ1bmN0aW9uICgkKSB7XHJcblx0Ly8gcHJpdmF0ZSBtZXRob2RzXHJcblx0dmFyIF9yZW1vdmFsRGVsYXkgPSAxNTA7XHJcblx0dmFyIF9zY3JvbGxCYXJXaWR0aCA9IGRldGVjdE1vZHVsZS5zY3JvbGxCYXJXaWR0aDtcclxuXHJcblx0dmFyIGlzT3BlblBvcHVwID0gZnVuY3Rpb24gKCkge1xyXG5cdFx0Ly8gY29uc29sZS5sb2coXCJvcGVuIHBvcC11cFwiKTtcclxuXHRcdCQoJ2JvZHknKS5jc3Moe1xyXG4gICAgICAncGFkZGluZy1yaWdodCc6IF9zY3JvbGxCYXJXaWR0aCArIFwicHhcIlxyXG4gICAgfSk7XHJcblx0XHQkKFwiaHRtbFwiKS5hZGRDbGFzcyhcInBvcC11cC1pcy1zaG93ZWRcIik7XHJcblx0fTtcclxuXHJcblx0dmFyIGlzQ2xvc2VQb3B1cCA9IGZ1bmN0aW9uICgpIHtcclxuXHRcdC8vIGNvbnNvbGUubG9nKFwiY2xvc2UgcG9wLXVwXCIpO1xyXG5cdFx0JChcImh0bWxcIikucmVtb3ZlQ2xhc3MoXCJwb3AtdXAtaXMtc2hvd2VkXCIpO1xyXG5cdFx0JCgnYm9keScpLmNzcygncGFkZGluZy1yaWdodCcsIDApO1xyXG5cdH07XHJcblxyXG5cclxuXHRyZXR1cm4ge1xyXG5cdFx0Ly8gcHVibGljIG1ldGhvZHNcclxuXHRcdGluaXRJbmxpbmU6IGZ1bmN0aW9uIChzZWxlY3Rvcikge1xyXG5cdFx0XHQkKHNlbGVjdG9yKS5kYXRhKFwiaWdub3JlLXNjcm9sbFwiLCB0cnVlKTtcclxuXHRcdFx0JChzZWxlY3RvcikubWFnbmlmaWNQb3B1cCh7XHJcblx0XHRcdFx0dHlwZTogJ2lubGluZScsXHJcblx0XHRcdFx0cHJlbG9hZGVyOiBmYWxzZSxcclxuXHRcdFx0XHRyZW1vdmFsRGVsYXk6IF9yZW1vdmFsRGVsYXksXHJcblx0XHRcdFx0bWFpbkNsYXNzOiAnbWZwLWZhZGUnLFxyXG5cdFx0XHRcdG92ZXJmbG93WTogJ3Zpc2libGUnLFxyXG5cdFx0XHRcdHNob3dDbG9zZUJ0bjogdHJ1ZSxcclxuXHRcdFx0XHRjYWxsYmFja3M6IHtcclxuXHRcdFx0XHRcdG9wZW46IGlzT3BlblBvcHVwLFxyXG5cdFx0XHRcdFx0Y2xvc2U6IGlzQ2xvc2VQb3B1cFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSk7XHJcblx0XHR9LFxyXG5cclxuXHRcdGluaXRBamF4OiBmdW5jdGlvbiAoc2VsZWN0b3IpIHtcclxuXHRcdFx0JChzZWxlY3RvcikuZGF0YShcImlnbm9yZS1zY3JvbGxcIiwgdHJ1ZSk7XHJcblx0XHRcdHZhciBfdGhpcyA9IHRoaXM7XHJcblx0XHRcdCQoc2VsZWN0b3IpLm1hZ25pZmljUG9wdXAoe1xyXG5cdFx0XHRcdHR5cGU6ICdhamF4JyxcclxuXHRcdFx0XHRwcmVsb2FkZXI6IHRydWUsXHJcblx0XHRcdFx0cmVtb3ZhbERlbGF5OiBfcmVtb3ZhbERlbGF5LFxyXG5cdFx0XHRcdG1haW5DbGFzczogJ21mcC1mYWRlJyxcclxuXHRcdFx0XHRvdmVyZmxvd1k6ICdoaWRkZW4nLFxyXG5cdFx0XHRcdHNob3dDbG9zZUJ0bjogZmFsc2UsXHJcblx0XHRcdFx0Y2FsbGJhY2tzOiB7XHJcblx0XHRcdFx0XHRvcGVuOiBpc09wZW5Qb3B1cCxcclxuXHRcdFx0XHRcdGFqYXhDb250ZW50QWRkZWQ6IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHRcdFx0Ly8gRm9ybVN0eWxlci5pbml0U2VsZWN0KFwiLnNlbGVjdFwiKTtcclxuXHRcdFx0XHRcdFx0Ly8gY29uc29sZS5sb2coX3RoaXMpO1xyXG5cdFx0XHRcdFx0XHQvLyBfdGhpcy5pbml0QWpheChcIi5qcy1wb3AtdXAtYWpheFwiKTtcclxuXHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRjbG9zZTogaXNDbG9zZVBvcHVwXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9KTtcclxuXHRcdH0sXHJcblxyXG5cdFx0b3BlbjogZnVuY3Rpb24gKGh0bWwpIHtcclxuXHRcdFx0JC5tYWduaWZpY1BvcHVwLmNsb3NlKCk7XHJcblx0XHRcdC8vd2FpdCBmb3IgYW5pbWF0aW9uXHJcblx0XHRcdHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG5cdFx0XHRcdC8vIE9wZW4gZGlyZWN0bHkgdmlhIEFQSVxyXG5cdFx0XHRcdCQubWFnbmlmaWNQb3B1cC5vcGVuKHtcclxuXHRcdFx0XHRcdGl0ZW1zOiB7XHJcblx0XHRcdFx0XHRcdHNyYzogaHRtbCwgLy8gY2FuIGJlIGEgSFRNTCBzdHJpbmcsIGpRdWVyeSBvYmplY3QsIG9yIENTUyBzZWxlY3RvclxyXG5cdFx0XHRcdFx0XHR0eXBlOiAnaW5saW5lJ1xyXG5cdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdHJlbW92YWxEZWxheTogX3JlbW92YWxEZWxheSxcclxuXHRcdFx0XHRcdG1haW5DbGFzczogJ21mcC1mYWRlJyxcclxuXHRcdFx0XHRcdG92ZXJmbG93WTogJ3Njcm9sbCcsXHJcblx0XHRcdFx0XHRzaG93Q2xvc2VCdG46IGZhbHNlLFxyXG5cdFx0XHRcdFx0Y2FsbGJhY2tzOiB7XHJcblx0XHRcdFx0XHRcdG9wZW46IGZ1bmN0aW9uICgpIHtcclxuXHRcdFx0XHRcdFx0XHRpc09wZW5Qb3B1cCgpO1xyXG5cdFx0XHRcdFx0XHRcdC8vIEZvcm1TdHlsZXIuaW5pdFNlbGVjdChcIi5zZWxlY3RcIik7XHJcblx0XHRcdFx0XHRcdFx0Ly8gUHJvZHVjdFNsaWRlci5pbml0KFwiLmpzLXByb2R1Y3Qtc2xpZGVyXCIsIFwiLmpzLXByb2R1Y3QtdGh1bWJzXCIpO1xyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRjbG9zZTogaXNDbG9zZVBvcHVwXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH0sIF9yZW1vdmFsRGVsYXkpO1xyXG5cdFx0fSxcclxuXHRcdG9wZW5BamF4OiBmdW5jdGlvbiAoaHJlZiwgc2V0dGluZykge1xyXG5cdFx0XHR2YXIgX3RoaXMgPSB0aGlzO1xyXG5cdFx0XHQkLmFqYXgoe1xyXG5cdFx0XHRcdHVybDogaHJlZixcclxuXHRcdFx0XHR0eXBlOiAnR0VUJyxcclxuXHRcdFx0XHRzdWNjZXNzOiBmdW5jdGlvbiAoZGF0YSkge1xyXG5cdFx0XHRcdFx0Ly9jb25zb2xlLmxvZyhkYXRhKTtcclxuXHRcdFx0XHRcdF90aGlzLm9wZW4oZGF0YSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9KTtcclxuXHJcblx0XHR9XHJcblx0fVxyXG59KGpRdWVyeSkpO1xyXG5cclxualF1ZXJ5KGZ1bmN0aW9uICgkKSB7XHJcblx0UG9wVXBNb2R1bGUuaW5pdElubGluZShcIi5qcy1wb3AtdXBcIik7XHJcblx0Ly9Qb3BVcE1vZHVsZS5pbml0QWpheChcIi5qcy1wb3AtdXAtYWpheFwiKTtcclxufSk7IC8vIHJlYWR5XHJcbiIsIihmdW5jdGlvbiAoJCkge1xyXG5cclxuICB2YXIgZmlsdGVycyA9ICQoJy5wb3J0Zm9saW8gIFtkYXRhLWZpbHRlcl0nKTtcclxuICB2YXIgZ3JpZCA9ICQoJy5wb3J0Zm9saW8tZ3JpZCcpO1xyXG4gIHZhciBhY3RpdmVDbGFzcyA9ICdpcy1zaG93JztcclxuICB2YXIgbWVkaWEgPSB3aW5kb3cubWF0Y2hNZWRpYShcIihtYXgtd2lkdGg6IDQ4ZW0pXCIpO1xyXG5cclxuICBncmlkLmlzb3RvcGUoe1xyXG4gICAgcGVyY2VudFBvc2l0aW9uOiB0cnVlLFxyXG4gICAgbGF5b3V0TW9kZTogJ2ZpdFJvd3MnLFxyXG4gICAgaXRlbVNlbGVjdG9yOiAnLnBvcnRmb2xpby1ncmlkX2l0ZW0nLFxyXG4gICAgbWFzb25yeToge1xyXG4gICAgICBjb2x1bW5XaWR0aDogJy5wb3J0Zm9saW8tZ3JpZF9pdGVtJ1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBmaWx0ZXJzLmNsaWNrKGZ1bmN0aW9uICgpIHtcclxuICAgIGZpbHRlcnMucmVtb3ZlQ2xhc3MoJ2lzLWFjdGl2ZScpO1xyXG4gICAgJCh0aGlzKS5hZGRDbGFzcygnaXMtYWN0aXZlJyk7XHJcblxyXG4gICAgdmFyIHNlbGVjdG9yID0gJCh0aGlzKS5hdHRyKCdkYXRhLWZpbHRlcicpO1xyXG4gICAgZ3JpZC5pc290b3BlKHtcclxuICAgICAgZmlsdGVyOiBzZWxlY3RvclxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfSk7XHJcblxyXG4gIGlmIChtZWRpYS5tYXRjaGVzKSB7XHJcbiAgICAkKFwiLnBvcnRmb2xpb19maWx0ZXJzXCIpLnJlbW92ZUNsYXNzKGFjdGl2ZUNsYXNzKTtcclxuICAgICQoXCIuZHJvcGRvd25cIikuYWRkQ2xhc3MoYWN0aXZlQ2xhc3MpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICAkKFwiLnBvcnRmb2xpb19maWx0ZXJzXCIpLmFkZENsYXNzKGFjdGl2ZUNsYXNzKTtcclxuICAgICQoXCIuZHJvcGRvd25cIikucmVtb3ZlQ2xhc3MoYWN0aXZlQ2xhc3MpO1xyXG4gIH1cclxuXHJcbiAgJCh3aW5kb3cpLnJlc2l6ZShmdW5jdGlvbiAoKSB7XHJcbiAgICBtZWRpYSA9IHdpbmRvdy5tYXRjaE1lZGlhKFwib25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQ4ZW0pXCIpO1xyXG5cclxuICAgIGlmIChtZWRpYS5tYXRjaGVzKSB7XHJcbiAgICAgICQoXCIucG9ydGZvbGlvX2ZpbHRlcnNcIikucmVtb3ZlQ2xhc3MoYWN0aXZlQ2xhc3MpO1xyXG4gICAgICAkKFwiLmRyb3Bkb3duXCIpLmFkZENsYXNzKGFjdGl2ZUNsYXNzKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICQoXCIucG9ydGZvbGlvX2ZpbHRlcnNcIikuYWRkQ2xhc3MoYWN0aXZlQ2xhc3MpO1xyXG4gICAgICAkKFwiLmRyb3Bkb3duXCIpLnJlbW92ZUNsYXNzKGFjdGl2ZUNsYXNzKTtcclxuICAgIH1cclxuXHJcbiAgfSk7XHJcblxyXG5cclxufShqUXVlcnkpKTtcclxuIiwiLy8gc2xpZGVycy5qc1xyXG5qUXVlcnkoZnVuY3Rpb24gKCQpIHtcclxuICAgIHZhciBhcnJvd0xlZnQgPSAnPGRpdiBjbGFzcz1cImFycm93LXNsaWRlIGFycm93LWxlZnQtc2xpZGVcIj48L2Rpdj4nO1xyXG4gICAgdmFyIGFycm93UmlnaHQgPSAnPGRpdiBjbGFzcz1cImFycm93LXNsaWRlIGFycm93LXJpZ2h0LXNsaWRlXCI+PC9kaXY+JztcclxuICAgIC8vIHByZXNldCBvcHRpb25zXHJcbiAgICB2YXIgaGVyb1NsaWRlciA9ICQoJy5iYW5uZXItc2xpZGVyJyk7XHJcbiAgICB2YXIgaGVyb09wdGlvbiA9IHtcclxuICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXHJcbiAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICAgICAgYXJyb3dzOiB0cnVlLFxyXG4gICAgICAgIGZhZGU6IHRydWUsXHJcbiAgICAgICAgZG90czogZmFsc2UsXHJcbiAgICAgICAgYXV0b3BsYXk6IGZhbHNlLFxyXG4gICAgICAgIG5leHRBcnJvdzogJzxkaXYgY2xhc3M9XCJzbGlkZXJfYnRuLS1uZXh0IHNsaWRlcl9idG5cIj4gJyArIGFycm93UmlnaHQgKyAnIDwvZGl2PicsXHJcbiAgICAgICAgcHJldkFycm93OiAnPGRpdiBjbGFzcz1cInNsaWRlcl9idG4tLXByZXYgc2xpZGVyX2J0blwiPicgKyBhcnJvd0xlZnQgKyAnPC9kaXY+JyxcclxuICAgICAgICBzcGVlZDogNTAwLFxyXG4gICAgICAgIGluZmluaXRlOiB0cnVlLFxyXG5cclxuICAgICAgICBjc3NFYXNlOiAnbGluZWFyJyxcclxuICAgICAgICBhY2Nlc3NpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgICByZXNwb25zaXZlOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDEyMDAsXHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGF1dG9wbGF5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGFycm93czpmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9O1xyXG5cclxuICAgIC8vIGluaXQgc2xpZGVyXHJcbiAgICBoZXJvU2xpZGVyLnNsaWNrKGhlcm9PcHRpb24pO1xyXG5cclxuICAgICQoJy5zbGlkZXItbWFpbicpLnNsaWNrKHtcclxuICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXHJcbiAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICAgICAgYXJyb3dzOiBmYWxzZSxcclxuICAgICAgICBhc05hdkZvcjogJy5zbGlkZXItbmF2JyxcclxuICAgICAgICB2ZXJ0aWNhbDogdHJ1ZSxcclxuICAgICAgICByZXNwb25zaXZlOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDEyMDEsXHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nczoge1xyXG4gICAgICAgICAgICAgICAgICAgIHZlcnRpY2FsOiBmYWxzZVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcblxyXG4gICAgfSk7XHJcblxyXG4gICAgJCgnLnNsaWRlci1uYXYnKS5zbGljayh7XHJcbiAgICAgICAgc2xpZGVzVG9TaG93OiA0LFxyXG4gICAgICAgIGFzTmF2Rm9yOiAnLnNsaWRlci1tYWluJyxcclxuICAgICAgICBhcnJvd3M6IHRydWUsXHJcbiAgICAgICAgdmVydGljYWw6IHRydWUsXHJcbiAgICAgICAgZm9jdXNPblNlbGVjdDogdHJ1ZSxcclxuICAgICAgICBuZXh0QXJyb3c6ICc8ZGl2IGNsYXNzPVwic2xpZGVyX2J0bi0tbmV4dCBzbGlkZXJfYnRuXCI+ICcgKyBhcnJvd1JpZ2h0ICsgJyA8L2Rpdj4nLFxyXG4gICAgICAgIHByZXZBcnJvdzogJzxkaXYgY2xhc3M9XCJzbGlkZXJfYnRuLS1wcmV2IHNsaWRlcl9idG5cIj4nICsgYXJyb3dMZWZ0ICsgJzwvZGl2PicsXHJcbiAgICAgICAgcmVzcG9uc2l2ZTogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBicmVha3BvaW50OiAxMjAxLFxyXG4gICAgICAgICAgICAgICAgc2V0dGluZ3M6IHtcclxuICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgc2xpZGVzVG9TaG93OiAzLFxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICB9KTtcclxuICAgICQoJy5wcm9kdWN0LXNsaWRlcicpLnNsaWNrKHtcclxuICAgICAgICBzbGlkZXNUb1Nob3c6IDYsXHJcbiAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXHJcbiAgICAgICAgYXJyb3dzOiB0cnVlLFxyXG4gICAgICAgIG5leHRBcnJvdzogJzxkaXYgY2xhc3M9XCJzbGlkZXJfYnRuLS1uZXh0IHNsaWRlcl9idG5cIj4gJyArIGFycm93UmlnaHQgKyAnIDwvZGl2PicsXHJcbiAgICAgICAgcHJldkFycm93OiAnPGRpdiBjbGFzcz1cInNsaWRlcl9idG4tLXByZXYgc2xpZGVyX2J0blwiPicgKyBhcnJvd0xlZnQgKyAnPC9kaXY+JyxcclxuICAgICAgICByZXNwb25zaXZlOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDEyMDAsXHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nczoge1xyXG4gICAgICAgICAgICAgICAgICAgIHNsaWRlc1RvU2hvdzogNSxcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBicmVha3BvaW50OiA3NjksXHJcbiAgICAgICAgICAgICAgICBzZXR0aW5nczoge1xyXG4gICAgICAgICAgICAgICAgICAgIHNsaWRlc1RvU2hvdzogNCxcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgICAgICB9LHtcclxuICAgICAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDU2MSxcclxuICAgICAgICAgICAgICAgIHNldHRpbmdzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2xpZGVzVG9TaG93OiAzLFxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIH0se1xyXG4gICAgICAgICAgICAgICAgYnJlYWtwb2ludDogNDgxLFxyXG4gICAgICAgICAgICAgICAgc2V0dGluZ3M6IHtcclxuICAgICAgICAgICAgICAgICAgICBzbGlkZXNUb1Nob3c6IDIsXHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICBdXHJcbiAgICB9KTtcclxuICAgIC8vXHJcbiAgICAvLyAkKHdpbmRvdykub24oJ3Jlc2l6ZSBvcmllbnRhdGlvbmNoYW5nZScsIGZ1bmN0aW9uKCkge1xyXG4gICAgLy8gICAgIGlmICgkKHdpbmRvdykud2lkdGgoKSA+IDEyMDApIHtcclxuICAgIC8vICAgICAgICAgJCgnLnNsaWRlci1uYXYnKS5zbGljaygndW5zbGljaycpO1xyXG4gICAgLy8gICAgICAgICAkKCcuc2xpZGVyLW5hdicpLnNsaWNrKHtcclxuICAgIC8vICAgICAgICAgICAgIHNsaWRlc1RvU2hvdzogNCxcclxuICAgIC8vICAgICAgICAgICAgIGFzTmF2Rm9yOiAnLnNsaWRlci1tYWluJyxcclxuICAgIC8vICAgICAgICAgICAgIHZlcnRpY2FsOiB0cnVlLFxyXG4gICAgLy8gICAgICAgICAgICAgZm9jdXNPblNlbGVjdDogdHJ1ZSxcclxuICAgIC8vICAgICAgICAgICAgIGFycm93czogdHJ1ZSxcclxuICAgIC8vICAgICAgICAgICAgIGF1dG9wbGF5OiBmYWxzZSxcclxuICAgIC8vICAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gfSk7XHJcblxyXG59KTsgLy8gcmVhZHlcclxuLy8gc2xpZGVycy5qcyBlbmQiLCIvKiBzbW9vdGggc2Nyb2xsaW5nICovXHJcbmpRdWVyeShmdW5jdGlvbiAoJCkge1xyXG5cdCQoJ2FbaHJlZio9XCIjXCJdOm5vdChbaHJlZj1cIiNcIl0pJykuY2xpY2soZnVuY3Rpb24gKCkge1xyXG5cdFx0aWYgKGxvY2F0aW9uLnBhdGhuYW1lLnJlcGxhY2UoL15cXC8vLCAnJykgPT0gdGhpcy5wYXRobmFtZS5yZXBsYWNlKC9eXFwvLywgJycpICYmIGxvY2F0aW9uLmhvc3RuYW1lID09IHRoaXMuaG9zdG5hbWUpIHtcclxuXHRcdFx0Ly8gcHJldmVudCBjb25mbGljdCB3aXRoIHRhYnMgYW5kIG90aGVyIHNjcmlwdCB1c2VkIGhhc2hcclxuXHRcdFx0aWYgKCAkKHRoaXMpLmRhdGEoXCJpZ25vcmUtc2Nyb2xsXCIpICkgcmV0dXJuO1xyXG5cclxuXHRcdFx0dmFyIHRhcmdldCA9ICQodGhpcy5oYXNoKTtcclxuXHRcdFx0dGFyZ2V0ID0gdGFyZ2V0Lmxlbmd0aCA/IHRhcmdldCA6ICQoJ1tuYW1lPScgKyB0aGlzLmhhc2guc2xpY2UoMSkgKyAnXScpO1xyXG5cdFx0XHRpZiAodGFyZ2V0Lmxlbmd0aCkge1xyXG5cdFx0XHRcdCQoJ2h0bWwsIGJvZHknKS5hbmltYXRlKHtcclxuXHRcdFx0XHRcdHNjcm9sbFRvcDogdGFyZ2V0Lm9mZnNldCgpLnRvcCAtIDUwXHJcblx0XHRcdFx0fSwgMTEwMCk7XHJcblx0XHRcdFx0cmV0dXJuIGZhbHNlO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fSk7XHJcbn0pO1xyXG4vKiBzbW9vdGggc2Nyb2xsaW5nIGVuZCovIiwialF1ZXJ5KGZ1bmN0aW9uICgkKSB7XHJcblx0Ly8gb24gY2FudmFzIG1lbnVcclxuXHR2YXIgJHRvdWNoID0gJCgnLmpzLXRvZ2dsZS1tZW51Jyk7XHJcblx0dmFyIGFjdGl2ZUNsYXNzID0gXCJpcy1zd2lwZS1tZW51LXNob3duXCI7XHJcblx0dmFyICRtZW51ID0gJCgnLnN3aXBlLW1lbnUnKTtcclxuXHR2YXIgJGNsb3NlID0gJCgnLmpzLW1lbnUtY2xvc2UnKTtcclxuXHR2YXIgJHdyYXBwZXIgPSAkKFwiYm9keVwiKTtcclxuXHR2YXIgc3RhcnRCcmVha3BvaW50ID0gXCIxMDI0cHhcIjtcclxuXHJcblx0Ly8gc2hvdy9oaWRlIG1lbnUgZnVuY3Rpb25zXHJcblx0ZnVuY3Rpb24gc2hvd01lbnUoKSB7XHJcblx0XHQkd3JhcHBlci5hZGRDbGFzcyhhY3RpdmVDbGFzcyk7XHJcblx0XHQvLyBpb3Mgc2Nyb2xsIGZpeFxyXG5cdFx0JChcImh0bWwsIGJvZHlcIikuY3NzKHtcclxuXHRcdFx0aGVpZ2h0OiBcIjEwMCVcIixcclxuXHRcdFx0XCJvdmVyZmxvdy15XCI6IFwiaGlkZGVuXCJcclxuXHRcdH0pO1xyXG5cclxuXHR9XHJcblx0ZnVuY3Rpb24gaGlkZU1lbnUoKSB7XHJcblx0XHQkd3JhcHBlci5yZW1vdmVDbGFzcyhhY3RpdmVDbGFzcyk7XHJcblx0XHQvLyBpb3Mgc2Nyb2xsIGZpeFxyXG5cdFx0JChcImh0bWwsIGJvZHlcIikuY3NzKHtcclxuXHRcdFx0aGVpZ2h0OiBcImF1dG9cIixcclxuXHRcdFx0XCJvdmVyZmxvdy15XCI6IFwiYXV0b1wiXHJcblx0XHR9KTtcclxuXHR9XHJcblx0XHJcblx0Ly8gZXZlbnQgbGlzdGVuZXJzXHJcblx0JHRvdWNoLm9uKCdjbGljaycsIGZ1bmN0aW9uIChlKSB7XHJcblx0XHRlLnByZXZlbnREZWZhdWx0KCk7XHJcblx0XHRlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG5cdFx0aWYgKCAkd3JhcHBlci5oYXNDbGFzcyhhY3RpdmVDbGFzcykgKSB7XHJcblx0XHRcdGhpZGVNZW51KCk7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRzaG93TWVudSgpO1xyXG5cdFx0fVxyXG5cdH0pO1xyXG5cclxuXHQkY2xvc2Uub24oJ2NsaWNrJywgZnVuY3Rpb24gKGUpIHtcclxuXHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblx0XHRoaWRlTWVudSgpO1xyXG5cdH0pO1xyXG5cclxuXHQkd3JhcHBlci5vbignY2xpY2snLCBmdW5jdGlvbiAoZSkge1xyXG5cdFx0aWYgKGUudGFyZ2V0LmNsYXNzTmFtZSAhPT0gXCJzd2lwZS1tZW51XCIpIHtcclxuXHRcdFx0aGlkZU1lbnUoKTtcclxuXHRcdH1cclxuXHR9KTtcclxuXHJcblx0JG1lbnUub24oJ2NsaWNrJywgZnVuY3Rpb24gKGUpIHtcclxuXHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblx0fSk7XHJcblxyXG5cdC8vIGNsb3NlIG1lbnUgaWYgdGFyZ2V0IGlzIGFuIGFuY2hvciBsaW5rXHJcblx0JG1lbnUuZmluZCgnYVtocmVmKj1cIiNcIl06bm90KFtocmVmPVwiI1wiXSknKS5vbignY2xpY2snLCBmdW5jdGlvbiAoZSkge1xyXG5cdFx0c2V0VGltZW91dChoaWRlTWVudSwgMTAwMCk7XHJcblx0fSk7XHJcblxyXG5cdCQod2luZG93KS5yZXNpemUoZnVuY3Rpb24gKCkge1xyXG5cdFx0dmFyIG1lZGlhID0gd2luZG93Lm1hdGNoTWVkaWEoXCJvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogXCIgKyBzdGFydEJyZWFrcG9pbnQgKyBcIilcIikubWF0Y2hlcztcclxuXHRcdGlmICghbWVkaWEpIHtcclxuXHRcdFx0aGlkZU1lbnUoKTtcclxuXHRcdH1cclxuXHR9KTtcclxuXHQvLyBvbiBjYW52YXMgbWVudSBlbmRcclxufSk7Il19
